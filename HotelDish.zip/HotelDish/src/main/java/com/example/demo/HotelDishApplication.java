package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelDishApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelDishApplication.class, args);
	}

}
