package lambda;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EightLambda {
	public static void main(String[] args) {
	 
  
    
    List<Integer> numbers=new ArrayList<>();
    numbers.add(10);
    numbers.add(108);
    numbers.add(200);
    numbers.add(101);
    numbers.add(105);
    numbers.add(91);
    numbers.add(105);
    numbers.add(107);
    numbers.add(102);
    numbers.add(101);
    

List<Integer> result=new ArrayList<Integer>();
result=numbers.stream().map(i ->mul(i)).collect(Collectors.toList());

result.forEach(i-> System.out.println(i));


result=numbers.stream().filter(i ->i%2==0).collect(Collectors.toList());
result.forEach(i-> System.out.println(i));



int resul=numbers.stream().reduce(0,(x,num)->x+num,Integer::sum);
System.out.println(resul);

}






public static int mul(int x)
{
    if(x%2==0)
    {
        return x;
    }
    return x*0;
}





}






